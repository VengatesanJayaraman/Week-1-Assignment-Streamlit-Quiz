import streamlit as st

st.set_page_config(page_title="Results | India Quiz", layout="centered")

st.title("📊 Quiz Results")

if "username" in st.session_state and "score" in st.session_state:
    st.write(f"👤 **User:** {st.session_state.username}")
    st.write(f"🏆 **Score:** {st.session_state.score} / 3")
else:
    st.warning("Please take the quiz first.")
