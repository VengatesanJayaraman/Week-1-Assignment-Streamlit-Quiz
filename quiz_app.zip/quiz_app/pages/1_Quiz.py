import streamlit as st
from utils import load_quiz_data, save_answer
import streamlit.components.v1 as components
import time

st.set_page_config(page_title="Quiz | India Quiz", layout="centered")

if "username" not in st.session_state:
    st.error("Please login from the Home page first.")
    st.stop()

quiz_data = load_quiz_data()
total_questions = len(quiz_data)

# Constants
TIMER_LIMIT = 30  # seconds

# Initialize state
if "question_index" not in st.session_state:
    st.session_state.question_index = 0
    st.session_state.score = 0
    st.session_state.start_time = time.time()
    st.session_state.answered = False

# Get current question
index = st.session_state.question_index

if index < total_questions:
    q = quiz_data[index]

    # Reset state if new question
    if st.session_state.get("current_q") != index:
        st.session_state.start_time = time.time()
        st.session_state.answered = False
        st.session_state.current_q = index

    elapsed = int(time.time() - st.session_state.start_time)
    time_left = max(0, TIMER_LIMIT - elapsed)
    progress = time_left / TIMER_LIMIT

    # Display question and timer
    st.subheader(f"Q{index + 1}: {q['question']}")
    user_answer = st.radio("Choose your answer:", q["options"], key=f"q{index}")

    # Timer and progress bar
    st.markdown(f"⏳ **Time left: {time_left} seconds**")
    st.progress(progress)

    # Auto-submit if timer runs out
    if time_left == 0 and not st.session_state.answered:
        selected = "No Answer"
        correct = q["answer"]
        save_answer(st.session_state.username, q["question"], selected, correct)
        st.session_state.answered = True
        st.session_state.question_index += 1
        st.rerun()

    # Manual submission
    if st.button("Submit Answer") and not st.session_state.answered:
        selected = user_answer
        correct = q["answer"]

        if selected == correct:
            st.success("✅ Correct!")
            st.session_state.score += 1
        else:
            st.error(f"❌ Wrong! Correct answer: {correct}")

        save_answer(st.session_state.username, q["question"], selected, correct)
        st.session_state.answered = True
        time.sleep(2)  # Short pause before going to next question
        st.session_state.question_index += 1
        st.rerun()
else:
    st.success("✅ You've completed the quiz!")
    st.info(f"👉 Check your final score in the 'Results' page.")
