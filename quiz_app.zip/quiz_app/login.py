import streamlit as st

st.set_page_config(page_title="Login | India Quiz", layout="centered")

st.title("🇮🇳 India Quiz - Login")

username = st.text_input("Enter your name to begin:")

if username:
    st.session_state.username = username
    st.success("Login successful! Go to 'Quiz' in sidebar to start.")
