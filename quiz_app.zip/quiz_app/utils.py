import csv
import os

def load_quiz_data():
    return [
        {
            "question": "What is the capital of India?",
            "options": ["Mumbai", "Delhi", "Chennai", "Kolkata"],
            "answer": "Delhi"
        },
        {
            "question": "Who is known as the Father of the Indian Constitution?",
            "options": ["Gandhi", "Ambedkar", "Nehru", "Tagore"],
            "answer": "Ambedkar"
        },
        {
            "question": "Which Indian state has the longest coastline?",
            "options": ["Kerala", "Gujarat", "Andhra Pradesh", "Tamil Nadu"],
            "answer": "Gujarat"
        }
    ]

def save_answer(username, question, selected, correct):
    file_path = "answers.csv"
    file_exists = os.path.isfile(file_path)
    
    with open(file_path, mode="a", newline="") as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(["Username", "Question", "Selected Answer", "Correct Answer"])
        writer.writerow([username, question, selected, correct])
